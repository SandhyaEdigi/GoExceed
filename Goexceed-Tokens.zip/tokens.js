import StyleDictionary from "style-dictionary-utils";
const config = {
  source: ["global.json"],
  platforms: {
    css: {
      transformGroup: "css/extended",
      transform:['color/css'],
      prefix: "ge",
      buildPath: "build/css/",
      files: [
        {
          destination: "_tokens1.css",
          format: "css/variables",
        }
      ]
    }
  }
};

const sd = StyleDictionary.extend(config);
sd.buildAllPlatforms();
